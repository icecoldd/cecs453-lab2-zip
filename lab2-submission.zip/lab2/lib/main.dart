import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class Artwork {
  const Artwork({
    required this.title,
    required this.artist,
    required this.year,
    this.imagePath,
  });

  final String title;
  final String artist;
  final String year;
  final String? imagePath;
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final List<Artwork> _artworks = const [
    Artwork(
      title: 'The Starry Night',
      artist: 'Vincent van Gogh',
      year: '1889',
      imagePath: 'assets/starry_night.jpg',
    ),
    Artwork(
      title: 'Mona Lisa',
      artist: 'Leonardo da Vinci',
      year: '1503–1506',
      imagePath: 'assets/mona_lisa.jpg',
    ),
  ];

  int _currentArtworkIndex = 0;

  void _showPreviousArtwork() {
    setState(() {
      _currentArtworkIndex =
          (_currentArtworkIndex - 1 + _artworks.length) % _artworks.length;
    });
  }

  void _showNextArtwork() {
    setState(() {
      _currentArtworkIndex = (_currentArtworkIndex + 1) % _artworks.length;
    });
  }

  @override
  Widget build(BuildContext context) {
    final Artwork currentArtwork = _artworks[_currentArtworkIndex];

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        backgroundColor: const Color(0xFFF9F7FC),
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                Expanded(
                  child: Center(
                    child: Container(
                      width: 280,
                      height: 360,
                      padding: const EdgeInsets.all(16),
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 8,
                            offset: Offset(0, 4),
                          ),
                        ],
                      ),
                      child: currentArtwork.imagePath != null
                          ? Image.asset(
                              currentArtwork.imagePath!,
                              fit: BoxFit.contain,
                            )
                          : Container(
                              color: const Color(0xFFE5E5E5),
                              alignment: Alignment.center,
                              child: const Text('Add second artwork'),
                            ),
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(16),
                  color: const Color(0xFFE8E6F0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        currentArtwork.title,
                        style: const TextStyle(
                          fontSize: 22,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${currentArtwork.artist} (${currentArtwork.year})',
                        style: const TextStyle(fontSize: 16),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _showPreviousArtwork,
                        child: const Text('Previous'),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: _showNextArtwork,
                        child: const Text('Next'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
