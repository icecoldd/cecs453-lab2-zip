import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:lab2/main.dart';

void main() {
  testWidgets('Art Space buttons switch between artworks', (
    WidgetTester tester,
  ) async {
    await tester.pumpWidget(const MyApp());

    expect(find.byType(Image), findsOneWidget);
    expect(find.text('The Starry Night'), findsOneWidget);
    expect(find.text('Vincent van Gogh (1889)'), findsOneWidget);
    expect(find.text('Previous'), findsOneWidget);
    expect(find.text('Next'), findsOneWidget);

    await tester.tap(find.text('Next'));
    await tester.pump();

    expect(find.byType(Image), findsOneWidget);
    expect(find.text('Mona Lisa'), findsOneWidget);
    expect(find.text('Leonardo da Vinci (c. 1503–1506)'), findsOneWidget);

    await tester.tap(find.text('Previous'));
    await tester.pump();

    expect(find.text('The Starry Night'), findsOneWidget);
  });
}
